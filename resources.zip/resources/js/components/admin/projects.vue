<template>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                
            
            <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Project List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>
                <tr>
                  <th style="width: 10px">ID</th>
                  <th style="width: 50%">Title</th>
                  <th>Developers</th>
                  <th style="width: 100px">Status</th>
                  <th style="width: 100px"></th>
                </tr>
               

                <tr v-for="(project, index) in projects.data" :key="project.id">
                            <td>{{ project.id }}</td>
                            <td>{{ project.title }}</td>
                            <td>Jhon Doe, Jhon Smith</td>
                            <td><span class="badge bg-light-blue">{{ 'Active'}}</span></td>
                            <td>
                            <div class="edbtn_group">
                            <button class="edit_btn" @click="editproject(project.id, index)"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>&nbsp;
                            <button class="delete_btn btn-primary" @click="deleteproject(project.id, index)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                            </div>
                            </td>                            
                        </tr> 

              </tbody>
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
             
            </div>
          </div>            
              
            </div>
            </div>
        


                   
                   


                     <div v-if="editModal">
                        <transition name="modal">
                        <div class="modal-mask">
                            <div class="modal-wrapper">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLongTitle">Edit Project</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"  @click="editModal=false">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>                                
                                    <div class="modal-body">
                                        <form>
                                            <div class="form-group">
                                                <label for="project_name">Project Name</label>
                                                <input name="project_name" id="project_name" type="text" class="form-control" v-model="editproject_data.name">
                                            </div>
                                            <div class="form-group">
                                                <label for="location">Location</label>
                                                 <input name="location" id="location" type="text" class="form-control"  v-model="editproject_data.location">
                                            </div>                                            
                                            <button type="submit" class="btn btn-primary" @click.prevent="updateproject(editproject_data.id, editproject_data.name, editproject_data.location)">Update</button>
                                            </form>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        </transition>
                    </div>
                    <div v-if="loding">
                    <loding></loding>
                    </div>
          
    </section>

</template>
<script>

  export default {

    data(){
        return{
        projects : {},
        loding: false,
        del_id : '',
        project_id : '',
        editModal: false,
        edit_project_name: '',
        editproject_data:{},
        edit_index: ''
        
        }
    },
    mounted(){     
      axios.get('/axios-projects').then( response => this.projects = response.data);
    },
 methods: {
        deleteproject(id, index) {
                //alert(id);
                this.project_id = id;
                this.$dialog.confirm("Do you want to delete this project with professors.", {
                loader: true
            })
                .then((dialog) => {                  
                    axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                    axios.post('/delete-project', { id: id} ).then( response => this.del_id = response.data);
                    this.projects.data.splice(index,1);
                    dialog.close();                   
                    setTimeout(() => {
                        console.log('Delete action completed ');
                        dialog.close();
                    }, 2500);

                })
                .catch(() => {
                    // Triggered when cancel button is clicked
                    console.log('Delete aborted');
                });
        },
        editproject(euid, index){
            this.editModal = true;            
            axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            axios.post('/projects/' + euid + '/edit').then( response => this.editproject_data = response.data[0]);
            this.edit_index = index;
        },
        updateproject(id, name, location){           
             this.editModal= false;
             //this.loding = true;
             axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
             axios.post('/update-project', { id: id, name: name, location: location}).then(
                 response =>{
                    this.projects.data[this.edit_index].name = name;
                    this.projects.data[this.edit_index].location = location;
                    // this.loding = false;
                    Vue.prototype.$toast.success({
                        title:'Success',
                        message:'project information updated',                
                    });
                 }
             );
             

        },

        getResults(page = 1) {            
			axios.get('/axios-projects?page=' + page)
				.then(response => {
					this.projects = response.data;
				});
		}
    }
    
  }
</script>
