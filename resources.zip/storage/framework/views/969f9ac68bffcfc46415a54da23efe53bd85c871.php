

<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
        <div class="row">
            <div class="col-md-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul style="margin:0; list-style:none; padding:0;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                    <li><?php echo e($error); ?></li>            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="box box-primary">
            
            <form method="post" action="/projects" role="form">
            <div class="box-body">
                <?php echo csrf_field(); ?>
                <!-- text input -->
                <div class="form-group">
                    <label>Project Title</label>
                    <input type="text" name="title" class="form-control" placeholder="Project Name">
                </div>
                <!-- textarea -->
                <div class="form-group">
                    <label>Project Description</label>
                    <textarea name="description" class="form-control" rows="4" placeholder="Project Description"></textarea>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

                </div>
              </form>
              
            </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>


    
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>